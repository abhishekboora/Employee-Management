package employee.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Main_class extends JFrame {

    Main_class() {
        // Get screen dimensions
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;

        // Create a central panel for all content
        JPanel centralPanel = new JPanel();
        centralPanel.setLayout(null);
        centralPanel.setOpaque(false); // Transparent to show the background
        int panelWidth = screenWidth / 2;
        int panelHeight = screenHeight / 2;
        centralPanel.setBounds((screenWidth - panelWidth) / 2, (screenHeight - panelHeight) / 2, panelWidth, panelHeight);

        // Heading
        JLabel heading = new JLabel("Employee Management System", JLabel.CENTER);
        heading.setFont(new Font("Raleway", Font.BOLD, 30));
        heading.setBounds(0, 20, panelWidth, 50); // Heading width matches panel
        centralPanel.add(heading);

        // Add Employee button (with no border)
        JButton add = new JButton("Add Employee");
        add.setBounds((panelWidth - 150) / 2 - 50, 120, 150, 40); // Left of center
        add.setForeground(Color.black);
        add.setBackground(Color.white);
        add.setFocusPainted(false); // Removes focus border
        add.setBorderPainted(false); // Removes button border
        add.addActionListener(e -> {
            new AddEmployee();
            setVisible(false);
        });
        centralPanel.add(add);

        // View Employee button
        JButton view = new JButton("View Employee");
        view.setBounds((panelWidth - 150) / 2 - 50, 200, 150, 40); // Right of center
        view.setForeground(Color.black);
        view.setBackground(Color.white);
        view.addActionListener(e -> {
            new View_Employee();
            setVisible(false);
        });
        centralPanel.add(view);

        // Remove Employee button
        JButton rem = new JButton("Remove Employee");
        rem.setBounds((panelWidth - 150) / 2-50, 280, 150, 40); // Centered
        rem.setForeground(Color.black);
        rem.setBackground(Color.white);
        rem.addActionListener(e -> new RemoveEmployee());
        centralPanel.add(rem);

        // Add central panel to the frame
        add(centralPanel);

        // Background image for the frame
        ImageIcon bgIcon = new ImageIcon(ClassLoader.getSystemResource("icons/LoginB.jpg"));
        Image bgImage = bgIcon.getImage().getScaledInstance(screenWidth, screenHeight, Image.SCALE_DEFAULT);
        ImageIcon scaledBgIcon = new ImageIcon(bgImage);
        JLabel bgLabel = new JLabel(scaledBgIcon);
        bgLabel.setBounds(0, 0, screenWidth, screenHeight);
        add(bgLabel);

        // Ensure the background appears below everything
        getContentPane().setLayout(null);
        bgLabel.setLayout(null);

        // Configure the JFrame
        setSize(screenWidth, screenHeight);
        setLocation(0, 0);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Main_class();
    }
}
