package employee.management.system;

import javax.swing.*;
import java.awt.*;

public class Splash extends JFrame {

    // Constructor to initialize the splash screen
    Splash() {
        // Get screen dimensions for full-screen mode
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;

        // Load and scale the splash screen image dynamically
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/front.gif"));
        Image i2 = i1.getImage().getScaledInstance(screenWidth, screenHeight, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, screenWidth, screenHeight);
        add(image);

        // Configure the JFrame for full-screen display
        setSize(screenWidth, screenHeight);
        setLocation(0, 0);
        setLayout(null);
        setUndecorated(true); // Removes the title bar and borders for a seamless look
        setVisible(true);

        // Display splash screen for a specified time, then launch the Login screen
        try {
            Thread.sleep(5000); // 5000 milliseconds = 5 seconds
            setVisible(false);
            new Login(); // Assuming Login is another class in your project
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Main method to run the splash screen
    public static void main(String[] args) {
        new Splash();
    }
}
