package employee.management.system;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Random;

public class AddEmployee extends JFrame implements ActionListener {
    Random ran = new Random();
    int number = ran.nextInt(999999);
    JTextField tname, tfname, taddress, tphone, taadhar, temail, tsalary, tdesignation;
    JLabel tempid;
    JDateChooser tdob;

    JButton add, back;

    JComboBox Boxeducation;

    AddEmployee() {

        getContentPane().setBackground(new Color(163, 255, 188));

        // Adjusting heading position to center
        JLabel heading = new JLabel("Add Employee Detail");
        heading.setBounds(350, 30, 500, 50); // Adjusted for center alignment
        heading.setFont(new Font("serif", Font.BOLD, 25));
        add(heading);

        // Adjust components' positions manually for centering
        int xOffset = 50; // Horizontal offset to help in centering
        int fieldWidth = 150;

        // Name Field
        JLabel name = new JLabel("Name");
        name.setBounds(50 + xOffset, 150, 150, 30);
        name.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(name);

        tname = new JTextField();
        tname.setBounds(200 + xOffset, 150, fieldWidth, 30);
        tname.setBackground(new Color(177, 252, 197));
        add(tname);

        // Father's Name
        JLabel fname = new JLabel("Father's Name");
        fname.setBounds(400 + xOffset, 150, 150, 30);
        fname.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(fname);

        tfname = new JTextField();
        tfname.setBounds(600 + xOffset, 150, fieldWidth, 30);
        tfname.setBackground(new Color(177, 252, 197));
        add(tfname);

        // Date of Birth
        JLabel dob = new JLabel("Date Of Birth");
        dob.setBounds(50 + xOffset, 200, 150, 30);
        dob.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(dob);

        tdob = new JDateChooser();
        tdob.setBounds(200 + xOffset, 200, fieldWidth, 30);
        tdob.setBackground(new Color(177, 252, 197));

        // Calculate the date 18 years ago from today and set it as the max date
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, -18);
        tdob.setMaxSelectableDate(cal.getTime());

        add(tdob);

        // Salary
        JLabel salary = new JLabel("Salary");
        salary.setBounds(400 + xOffset, 200, 150, 30);
        salary.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(salary);

        tsalary = new JTextField();
        tsalary.setBounds(600 + xOffset, 200, fieldWidth, 30);
        tsalary.setBackground(new Color(177, 252, 197));
        add(tsalary);

        // Address
        JLabel address = new JLabel("Address");
        address.setBounds(50 + xOffset, 250, 150, 30);
        address.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(address);

        taddress = new JTextField();
        taddress.setBounds(200 + xOffset, 250, fieldWidth, 30);
        taddress.setBackground(new Color(177, 252, 197));
        add(taddress);

        // Phone
        JLabel phone = new JLabel("Phone");
        phone.setBounds(400 + xOffset, 250, 150, 30);
        phone.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(phone);

        tphone = new JTextField();
        tphone.setBounds(600 + xOffset, 250, fieldWidth, 30);
        tphone.setBackground(new Color(177, 252, 197));
        add(tphone);

        // Email
        JLabel email = new JLabel("Email");
        email.setBounds(50 + xOffset, 300, 150, 30);
        email.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(email);

        temail = new JTextField();
        temail.setBounds(200 + xOffset, 300, fieldWidth, 30);
        temail.setBackground(new Color(177, 252, 197));
        add(temail);

        // Education
        JLabel education = new JLabel("Highest Education");
        education.setBounds(400 + xOffset, 300, 150, 30);
        education.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(education);

        String items[] = {"BBA", "B.Tech", "BCA", "BA", "BSC", "B.COM", "MBA", "MCA", "MA", "MTech", "MSC", "PHD"};
        Boxeducation = new JComboBox(items);
        Boxeducation.setBackground(new Color(177, 252, 197));
        Boxeducation.setBounds(600 + xOffset, 300, fieldWidth, 30);
        add(Boxeducation);

        // Aadhar
        JLabel aadhar = new JLabel("Aadhar Number");
        aadhar.setBounds(400 + xOffset, 350, 150, 30);
        aadhar.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(aadhar);

        taadhar = new JTextField();
        taadhar.setBounds(600 + xOffset, 350, fieldWidth, 30);
        taadhar.setBackground(new Color(177, 252, 197));
        add(taadhar);

        // Employee ID
        JLabel empid = new JLabel("Employee ID");
        empid.setBounds(50 + xOffset, 400, 150, 30);
        empid.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(empid);

        tempid = new JLabel("" + number);
        tempid.setBounds(200 + xOffset, 400, fieldWidth, 30);
        tempid.setFont(new Font("SAN_SARIF", Font.BOLD, 20));
        tempid.setForeground(Color.RED);
        add(tempid);

        // Designation
        JLabel designation = new JLabel("Designation");
        designation.setBounds(50 + xOffset, 350, 150, 30);
        designation.setFont(new Font("SAN_SERIF", Font.BOLD, 20));
        add(designation);

        tdesignation = new JTextField();
        tdesignation.setBounds(200 + xOffset, 350, fieldWidth, 30);
        tdesignation.setBackground(new Color(177, 252, 197));
        add(tdesignation);

        // Add Button
        add = new JButton("ADD");
        add.setBounds(450 + xOffset, 550, 150, 40);
        add.setBackground(Color.black);
        add.setForeground(Color.WHITE);
        add.addActionListener(this);
        add(add);

        // Back Button
        back = new JButton("BACK");
        back.setBounds(250 + xOffset, 550, 150, 40);
        back.setBackground(Color.black);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);

        setSize(900, 700);
        setLayout(null);
        setLocationRelativeTo(null); // Center the frame
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Open in full-screen mode
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == add) {
            String name = tname.getText();
            String fname = tfname.getText();
            String dob = ((JTextField) tdob.getDateEditor().getUiComponent()).getText();
            String salary = tsalary.getText();
            String address = taddress.getText();
            String aadhar = taadhar.getText();
            String phone = tphone.getText().trim();
            String email = temail.getText();
            String education = (String) Boxeducation.getSelectedItem();
            String designation = tdesignation.getText();
            String empID = tempid.getText();

            // Regular expressions for validation
            String phonePattern = "^\\d{10}$"; // Phone must be exactly 10 digits
            String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$"; // Email pattern
            String salaryPattern = "^\\d+$"; // Salary must be a positive integer
            String aadharPattern = "^\\d{12}$"; // Aadhar number must be exactly 12 digits

            // Validating phone number
            if (!phone.matches(phonePattern)) {
                JOptionPane.showMessageDialog(null, "Invalid phone number. It must be exactly 10 digits.");
                return;
            }

            // Validating email
            if (!email.matches(emailPattern)) {
                JOptionPane.showMessageDialog(null, "Invalid email address.");
                return;
            }

            // Validating salary
            if (!salary.matches(salaryPattern)) {
                JOptionPane.showMessageDialog(null, "Salary must be a valid number.");
                return;
            }

            // Validating Aadhar number
            if (!aadhar.matches(aadharPattern)) {
                JOptionPane.showMessageDialog(null, "Aadhar number must be exactly 12 digits.");
                return;
            }

            // Check for empty fields
            if (name.isEmpty() || fname.isEmpty() || dob.isEmpty() || salary.isEmpty() || address.isEmpty() || phone.isEmpty() || email.isEmpty() || education.isEmpty() || designation.isEmpty() || aadhar.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                return;
            }

            try {
                conn c = new conn();
                String query = "insert into employee values('" + name + "', '" + fname + "', '" + dob + "', '" + salary + "','" + address + "', '" + phone + "', '" + email + "', '" + education + "', '" + designation + "','" + aadhar + "', '" + empID + "')";
                c.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Details added successfully");
                setVisible(false);
                new Main_class();
            } catch (Exception E) {
                E.printStackTrace();
            }

        } else {
            setVisible(false);
            new Main_class();
        }
    }

    public static void main(String[] args) {
        new AddEmployee();
    }
}
