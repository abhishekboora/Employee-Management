package employee.management.system;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.*;

public class Login extends JFrame implements ActionListener {

    JTextField tusername;
    JPasswordField tpassword;
    JButton login, back;

    Login() {
        // Get screen dimensions
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;

        // Centering panel dimensions
        int panelWidth = screenWidth / 3;
        int panelHeight = screenHeight / 2;

        // Create a central panel to hold the form components
        JPanel centralPanel = new JPanel();
        centralPanel.setLayout(null);
        centralPanel.setBounds((screenWidth - panelWidth) / 2, (screenHeight - panelHeight) / 2, panelWidth, panelHeight);
        centralPanel.setOpaque(false); // Makes the panel transparent so the background image is visible

        // Username label
        JLabel username = new JLabel("Username:");
        username.setFont(new Font("Arial", Font.BOLD, 16));
        username.setBounds(50, 50, 100, 30);
        centralPanel.add(username);

        // Username input
        tusername = new JTextField();
        tusername.setBounds(160, 50, 200, 30);
        centralPanel.add(tusername);

        // Password label
        JLabel password = new JLabel("Password:");
        password.setFont(new Font("Arial", Font.BOLD, 16));
        password.setBounds(50, 100, 100, 30);
        centralPanel.add(password);

        // Password input
        tpassword = new JPasswordField();
        tpassword.setBounds(160, 100, 200, 30);
        centralPanel.add(tpassword);

        // Login button
        login = new JButton("LOGIN");
        login.setBounds(100, 180, 100, 40);
        login.setBackground(Color.BLACK);
        login.setForeground(Color.WHITE);
        login.addActionListener(this);
        centralPanel.add(login);

        // Back button
        back = new JButton("BACK");
        back.setBounds(220, 180, 100, 40);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        centralPanel.add(back);

        // Add central panel to the frame
        add(centralPanel);

        // Background image for the frame
        ImageIcon bgIcon = new ImageIcon(ClassLoader.getSystemResource("icons/LoginB.jpg"));
        Image bgImage = bgIcon.getImage().getScaledInstance(screenWidth, screenHeight, Image.SCALE_DEFAULT);
        ImageIcon scaledBgIcon = new ImageIcon(bgImage);
        JLabel bgLabel = new JLabel(scaledBgIcon);
        bgLabel.setBounds(0, 0, screenWidth, screenHeight);
        add(bgLabel);

        // Ensure the central panel appears above the background
        getContentPane().setLayout(null);

        // Configure the JFrame
        setSize(screenWidth, screenHeight);
        setLocation(0, 0);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == login) {
            try {
                String username = tusername.getText();
                String password = String.valueOf(tpassword.getPassword());

                conn conn = new conn(); // Assuming you have a `conn` class for database operations
                String query = "SELECT * FROM login WHERE username = '" + username + "' AND password = '" + password + "'";
                ResultSet resultSet = conn.statement.executeQuery(query);

                if (resultSet.next()) {
                    setVisible(false);
                    new Main_class(); // Assuming Main_class is the next screen
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password");
                }
            } catch (Exception ex) {
                ex.printStackTrace(System.err);
            }
        } else if (e.getSource() == back) {
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
